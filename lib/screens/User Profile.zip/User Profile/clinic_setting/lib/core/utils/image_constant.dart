class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Clinic details images
  static String imgBiCameraFill = '$imagePath/img_bi_camera_fill.svg';

  // Clinic details_filled images
  static String imgEllipse759 = '$imagePath/img_ellipse_759.png';

  // Common images
  static String imgArrowDown = '$imagePath/img_arrow_down.svg';

  static String imgIconoirCancel = '$imagePath/img_iconoir_cancel.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
