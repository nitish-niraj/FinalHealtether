import 'package:flutter/material.dart';
import 'package:clinic_setting/presentation/clinic_details_screen/clinic_details_screen.dart';
import 'package:clinic_setting/presentation/clinic_details_filled_screen/clinic_details_filled_screen.dart';
import 'package:clinic_setting/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String clinicDetailsScreen = '/clinic_details_screen';

  static const String clinicDetailsFilledScreen =
      '/clinic_details_filled_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    clinicDetailsScreen: (context) => ClinicDetailsScreen(),
    clinicDetailsFilledScreen: (context) => ClinicDetailsFilledScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
