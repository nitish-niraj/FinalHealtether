import 'package:clinic_setting/core/app_export.dart';
import 'package:clinic_setting/widgets/app_bar/appbar_leading_image.dart';
import 'package:clinic_setting/widgets/app_bar/appbar_title.dart';
import 'package:clinic_setting/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:clinic_setting/widgets/app_bar/custom_app_bar.dart';
import 'package:clinic_setting/widgets/custom_elevated_button.dart';
import 'package:clinic_setting/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';

class ClinicDetailsScreen extends StatelessWidget {
  ClinicDetailsScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController nameEditTextController = TextEditingController();

  TextEditingController nameEditTextController1 = TextEditingController();

  TextEditingController mobileNoEditTextController = TextEditingController();

  TextEditingController emailEditTextController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: Container(
                width: double.maxFinite,
                padding: EdgeInsets.symmetric(
                  horizontal: 15.h,
                  vertical: 16.v,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Add new clinic".toUpperCase(),
                          style: TextStyle(
                            color: theme.colorScheme.onErrorContainer,
                            fontSize: 14.fSize,
                            fontFamily: 'Montserrat',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(height: 4.v),
                        SizedBox(
                          width: 47.h,
                          child: Divider(),
                        ),
                      ],
                    ),
                    SizedBox(height: 15.v),
                    _buildFrame(context),
                    SizedBox(height: 16.v),
                    _buildNameEditText(context),
                    SizedBox(height: 12.v),
                    _buildNameEditText1(context),
                    SizedBox(height: 12.v),
                    _buildMobileNoEditText(context),
                    SizedBox(height: 12.v),
                    _buildEmailEditText(context),
                    SizedBox(height: 5.v),
                  ],
                ),
              ),
            ),
          ),
        ),
        bottomNavigationBar: _buildSave(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 40.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 60.v,
          bottom: 9.v,
        ),
      ),
      title: AppbarTitle(
        text: "Settings",
        margin: EdgeInsets.only(
          left: 8.h,
          top: 61.v,
          bottom: 6.v,
        ),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconoirCancel,
          margin: EdgeInsets.fromLTRB(16.h, 58.v, 16.h, 7.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildFrame(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 43.h),
      child: Row(
        children: [
          Container(
            height: 120.adaptSize,
            width: 120.adaptSize,
            padding: EdgeInsets.all(40.h),
            decoration: AppDecoration.fillOnError.copyWith(
              borderRadius: BorderRadiusStyle.circleBorder60,
            ),
            child: CustomImageView(
              imagePath: ImageConstant.imgBiCameraFill,
              height: 40.adaptSize,
              width: 40.adaptSize,
              alignment: Alignment.center,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 16.h,
              top: 30.v,
              bottom: 26.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Clinic logo",
                  style: TextStyle(
                    color: appTheme.black900,
                    fontSize: 16.fSize,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(
                  width: 178.h,
                  child: Text(
                    "Click on the camera to add Clinic logo.",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: appTheme.blueGray400,
                      fontSize: 13.fSize,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNameEditText(BuildContext context) {
    return CustomTextFormField(
      controller: nameEditTextController,
      hintText: "Clinic name",
    );
  }

  /// Section Widget
  Widget _buildNameEditText1(BuildContext context) {
    return CustomTextFormField(
      controller: nameEditTextController1,
      hintText: "Admin name",
    );
  }

  /// Section Widget
  Widget _buildMobileNoEditText(BuildContext context) {
    return CustomTextFormField(
      controller: mobileNoEditTextController,
      hintText: "Mobile no",
      textInputType: TextInputType.phone,
    );
  }

  /// Section Widget
  Widget _buildEmailEditText(BuildContext context) {
    return CustomTextFormField(
      controller: emailEditTextController,
      hintText: "Clinic’s Email",
      textInputAction: TextInputAction.done,
      textInputType: TextInputType.emailAddress,
    );
  }

  /// Section Widget
  Widget _buildSaveButton(BuildContext context) {
    return CustomElevatedButton(
      text: "Save",
    );
  }

  /// Section Widget
  Widget _buildSave(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        left: 55.h,
        right: 55.h,
        bottom: 21.v,
      ),
      decoration: AppDecoration.fillOnPrimaryContainer,
      child: _buildSaveButton(context),
    );
  }
}
