package com.clinicsetting.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
