class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Common images
  static String imgArrowDown = '$imagePath/img_arrow_down.svg';

  static String imgIconoirCancel = '$imagePath/img_iconoir_cancel.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
