import 'package:flutter/material.dart';
import 'package:payment_setting/presentation/clinic_settings_new_clinic_seven_screen/clinic_settings_new_clinic_seven_screen.dart';
import 'package:payment_setting/presentation/clinic_settings_new_clinic_eight_screen/clinic_settings_new_clinic_eight_screen.dart';

class AppRoutes {
  static const String clinicSettingsNewClinicSevenScreen =
      '/clinic_settings_new_clinic_seven_screen';

  static const String clinicSettingsNewClinicEightScreen =
      '/clinic_settings_new_clinic_eight_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    clinicSettingsNewClinicSevenScreen: (context) =>
        ClinicSettingsNewClinicSevenScreen(),
    clinicSettingsNewClinicEightScreen: (context) =>
        ClinicSettingsNewClinicEightScreen(),
  };
}
