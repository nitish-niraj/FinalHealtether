import '../clinic_settings_new_clinic_eight_screen/widgets/textfield_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:payment_setting/core/app_export.dart';
import 'package:payment_setting/widgets/app_bar/appbar_leading_image.dart';
import 'package:payment_setting/widgets/app_bar/appbar_title.dart';
import 'package:payment_setting/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:payment_setting/widgets/app_bar/custom_app_bar.dart';
import 'package:payment_setting/widgets/custom_elevated_button.dart';

class ClinicSettingsNewClinicEightScreen extends StatelessWidget {
  const ClinicSettingsNewClinicEightScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.all(16.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Payments settings".toUpperCase(),
                    style: TextStyle(
                      color: theme.colorScheme.onPrimaryContainer,
                      fontSize: 14.fSize,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 4.v),
                  SizedBox(
                    width: 47.h,
                    child: Divider(),
                  ),
                ],
              ),
              SizedBox(height: 15.v),
              Row(
                children: [
                  CustomElevatedButton(
                    height: 40.v,
                    width: 104.h,
                    text: "Phone Pe",
                    buttonStyle: CustomButtonStyles.fillOnSecondaryContainer,
                  ),
                  CustomElevatedButton(
                    height: 39.v,
                    width: 75.h,
                    text: "Others",
                    margin: EdgeInsets.only(left: 8.h),
                  ),
                ],
              ),
              SizedBox(height: 16.v),
              _buildTextField(context),
            ],
          ),
        ),
        bottomNavigationBar: _buildSave(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 40.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 24.v,
          bottom: 9.v,
        ),
      ),
      title: AppbarTitle(
        text: "Settings",
        margin: EdgeInsets.only(left: 8.h),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconoirCancel,
          margin: EdgeInsets.fromLTRB(16.h, 22.v, 16.h, 7.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildTextField(BuildContext context) {
    return Expanded(
      child: ListView.separated(
        physics: BouncingScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            height: 12.v,
          );
        },
        itemCount: 3,
        itemBuilder: (context, index) {
          return TextfieldItemWidget();
        },
      ),
    );
  }

  /// Section Widget
  Widget _buildSave(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        left: 55.h,
        right: 55.h,
        bottom: 21.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: CustomElevatedButton(
        text: "Save",
        buttonStyle: CustomButtonStyles.fillPrimaryContainer,
      ),
    );
  }
}
