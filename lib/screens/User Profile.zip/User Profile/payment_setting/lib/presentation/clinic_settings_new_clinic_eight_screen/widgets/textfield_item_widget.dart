import 'package:flutter/material.dart';
import 'package:payment_setting/core/app_export.dart';

// ignore: must_be_immutable
class TextfieldItemWidget extends StatelessWidget {
  const TextfieldItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 13.v,
      ),
      decoration: AppDecoration.fillGray,
      child: Text(
        "12000-00145-96015",
        style: TextStyle(
          color: theme.colorScheme.onPrimaryContainer,
          fontSize: 16.fSize,
          fontFamily: 'Poppins',
          fontWeight: FontWeight.w400,
        ),
      ),
    );
  }
}
