import '../clinic_settings_new_clinic_seven_screen/widgets/localnavigations_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:payment_setting/core/app_export.dart';
import 'package:payment_setting/widgets/app_bar/appbar_leading_image.dart';
import 'package:payment_setting/widgets/app_bar/appbar_title.dart';
import 'package:payment_setting/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:payment_setting/widgets/app_bar/custom_app_bar.dart';
import 'package:payment_setting/widgets/custom_elevated_button.dart';
import 'package:payment_setting/widgets/custom_text_form_field.dart';

class ClinicSettingsNewClinicSevenScreen extends StatelessWidget {
  ClinicSettingsNewClinicSevenScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController merchantIdValueController = TextEditingController();

  TextEditingController saltKeyValueController = TextEditingController();

  TextEditingController saltIndexValueController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.all(16.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Payments settings".toUpperCase(),
                    style: TextStyle(
                      color: theme.colorScheme.onPrimaryContainer,
                      fontSize: 14.fSize,
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 4.v),
                  SizedBox(
                    width: 47.h,
                    child: Divider(),
                  ),
                ],
              ),
              SizedBox(height: 15.v),
              _buildLocalNavigations(context),
              SizedBox(height: 16.v),
              _buildMerchantIdValue(context),
              SizedBox(height: 12.v),
              _buildSaltKeyValue(context),
              SizedBox(height: 12.v),
              _buildSaltIndexValue(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
        bottomNavigationBar: _buildSave1(context),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 40.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 24.v,
          bottom: 9.v,
        ),
      ),
      title: AppbarTitle(
        text: "Settings",
        margin: EdgeInsets.only(left: 8.h),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconoirCancel,
          margin: EdgeInsets.fromLTRB(16.h, 22.v, 16.h, 7.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildLocalNavigations(BuildContext context) {
    return Wrap(
      runSpacing: 8.v,
      spacing: 8.h,
      children:
          List<Widget>.generate(2, (index) => LocalnavigationsItemWidget()),
    );
  }

  /// Section Widget
  Widget _buildMerchantIdValue(BuildContext context) {
    return CustomTextFormField(
      controller: merchantIdValueController,
      hintText: "Merchant ID *",
    );
  }

  /// Section Widget
  Widget _buildSaltKeyValue(BuildContext context) {
    return CustomTextFormField(
      controller: saltKeyValueController,
      hintText: "Salt Key *",
    );
  }

  /// Section Widget
  Widget _buildSaltIndexValue(BuildContext context) {
    return CustomTextFormField(
      controller: saltIndexValueController,
      hintText: "Salt Index *",
      textInputAction: TextInputAction.done,
    );
  }

  /// Section Widget
  Widget _buildSave(BuildContext context) {
    return CustomElevatedButton(
      text: "Save",
    );
  }

  /// Section Widget
  Widget _buildSave1(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(
        left: 55.h,
        right: 55.h,
        bottom: 21.v,
      ),
      decoration: AppDecoration.fillWhiteA,
      child: _buildSave(context),
    );
  }
}
