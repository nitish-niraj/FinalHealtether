import 'package:flutter/material.dart';
import 'package:payment_setting/core/app_export.dart';

// ignore: must_be_immutable
class LocalnavigationsItemWidget extends StatelessWidget {
  const LocalnavigationsItemWidget({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return RawChip(
      padding: EdgeInsets.symmetric(
        horizontal: 12.h,
        vertical: 10.v,
      ),
      showCheckmark: true,
      labelPadding: EdgeInsets.zero,
      label: Text(
        "Phone Pe",
        style: TextStyle(
          color: theme.colorScheme.onPrimaryContainer,
          fontSize: 16.fSize,
          fontFamily: 'Montserrat',
          fontWeight: FontWeight.w600,
        ),
      ),
      selected: false,
      backgroundColor: theme.colorScheme.onSecondaryContainer,
      selectedColor: theme.colorScheme.primary,
      shape: RoundedRectangleBorder(
        side: BorderSide.none,
        borderRadius: BorderRadius.circular(
          8.h,
        ),
      ),
      onSelected: (value) {},
    );
  }
}
