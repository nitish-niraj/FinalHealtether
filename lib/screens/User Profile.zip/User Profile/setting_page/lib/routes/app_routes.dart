import 'package:flutter/material.dart';
import 'package:setting_page/presentation/profile_settings_screen/profile_settings_screen.dart';

class AppRoutes {
  static const String profileSettingsScreen = '/profile_settings_screen';

  static Map<String, WidgetBuilder> routes = {
    profileSettingsScreen: (context) => ProfileSettingsScreen()
  };
}
