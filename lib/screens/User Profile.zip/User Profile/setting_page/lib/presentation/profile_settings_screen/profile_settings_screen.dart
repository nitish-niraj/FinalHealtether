import 'package:flutter/material.dart';
import 'package:setting_page/core/app_export.dart';
import 'package:setting_page/widgets/app_bar/appbar_leading_image.dart';
import 'package:setting_page/widgets/app_bar/appbar_title.dart';
import 'package:setting_page/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:setting_page/widgets/app_bar/custom_app_bar.dart';
import 'package:setting_page/widgets/custom_elevated_button.dart';


class ProfileSettingsScreen extends StatelessWidget {
  ProfileSettingsScreen({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 16.h),
          child: Column(
            children: [
              _buildFrame(context),
              SizedBox(height: 17.v),
              _buildClickOptions1(context),
              SizedBox(height: 10.v),
              _buildClickOptions2(context),
              SizedBox(height: 10.v),
              _buildClickOptions3(context),
              SizedBox(height: 10.v),
              _buildClickOptions4(context),
              SizedBox(height: 10.v),
              _buildClickOptions5(context),
              SizedBox(height: 10.v),
            Container(
              width: 358.h,
              padding: EdgeInsets.symmetric(
                horizontal: 16.h,
                vertical: 15.v,
              ),
              decoration: AppDecoration.fillGray.copyWith(
                borderRadius: BorderRadiusStyle.roundedBorder2,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 4.v),
                  GestureDetector(
                    onTap: () {
                      // Handle button tap here
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.transparent, // Change the color as needed
                      ),
                      child: Text(
                        'Support',
                        style: TextStyle(
                            color: Colors.black, // Change the text color as needed
                            fontWeight: FontWeight.w500,
                            fontSize: 15
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
              SizedBox(height: 8.v),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "© Copyright 2023 HealTether. All Rights Reserved",
                  style: TextStyle(
                    color: appTheme.blueGray400,
                    fontSize: 13.fSize,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 40.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 34.v,
          bottom: 35.v,
        ),
      ),
      title: AppbarTitle(
        text: "Settings",
        margin: EdgeInsets.only(left: 8.h),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconoirCancel,
          margin: EdgeInsets.fromLTRB(16.h, 32.v, 16.h, 33.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildFrame(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: 29.v,
        bottom: 28.v,
      ),
      decoration: AppDecoration.outlineGray,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgEllipse759,
            height: 120.adaptSize,
            width: 120.adaptSize,
            radius: BorderRadius.circular(
              60.h,
            ),
            margin: EdgeInsets.only(bottom: 6.v),
          ),
          Padding(
            padding: EdgeInsets.only(
              left: 16.h,
              top: 4.v,
              bottom: 6.v,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomElevatedButton(
                  width: 114.h,
                  text: "Super Admin",
                ),
                SizedBox(height: 4.v),
                Text(
                  "Dr. Kim Jones",
                  style: TextStyle(
                    color: appTheme.black900,
                    fontSize: 23.fSize,
                    fontFamily: 'Montserrat',
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 5.v),
                Text(
                  "MBBS, DLO, MS(ENT)",
                  style: TextStyle(
                    color: appTheme.black900,
                    fontSize: 14.fSize,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBox(height: 4.v),
                Text(
                  "ENT specialist",
                  style: TextStyle(
                    color: appTheme.indigo500,
                    fontSize: 11.fSize,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildClickOptions1(BuildContext context) {
    return Container(
      width: 358.h,
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 4.v),
          GestureDetector(
            onTap: () {
              // Handle button tap here
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent, // Change the color as needed
              ),
              child: Text(
                'Clinic Setting',
                style: TextStyle(
                  color: Colors.black, // Change the text color as needed
                  fontWeight: FontWeight.w500,
                  fontSize: 15
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildClickOptions2(BuildContext context) {
    return Container(
      width: 358.h,
      padding: EdgeInsets.all(16.h),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 3.v),
          GestureDetector(
            onTap: () {
              // Handle button tap here
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent, // Change the color as needed
              ),
              child: Text(
                'Appointment Slots',
                style: TextStyle(
                    color: Colors.black, // Change the text color as needed
                    fontWeight: FontWeight.w500,
                    fontSize: 15
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildClickOptions3(BuildContext context) {
    return Container(
      width: 358.h,
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 4.v),
          GestureDetector(
            onTap: () {
              // Handle button tap here
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent, // Change the color as needed
              ),
              child: Text(
                'Payments Setting',
                style: TextStyle(
                    color: Colors.black, // Change the text color as needed
                    fontWeight: FontWeight.w500,
                    fontSize: 15
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildClickOptions4(BuildContext context) {
    return Container(
      width: 358.h,
      padding: EdgeInsets.symmetric(
        horizontal: 16.h,
        vertical: 15.v,
      ),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 4.v),
          GestureDetector(
            onTap: () {
              // Handle button tap here
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent, // Change the color as needed
              ),
              child: Text(
                'Notification Setting',
                style: TextStyle(
                    color: Colors.black, // Change the text color as needed
                    fontWeight: FontWeight.w500,
                    fontSize: 15
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildClickOptions5(BuildContext context) {
    return Container(
      width: 358.h,
      padding: EdgeInsets.all(16.h),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder2,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(height: 3.v),
          GestureDetector(
            onTap: () {
              // Handle button tap here
            },
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent, // Change the color as needed
              ),
              child: Text(
                'App Permission',
                style: TextStyle(
                    color: Colors.black, // Change the text color as needed
                    fontWeight: FontWeight.w500,
                    fontSize: 15
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
