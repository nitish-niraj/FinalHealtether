import 'package:flutter/material.dart';
import 'package:nitish_s_application3/presentation/notifications_settings_one_screen/notifications_settings_one_screen.dart';
import 'package:nitish_s_application3/presentation/permissions_settings_screen/permissions_settings_screen.dart';
import 'package:nitish_s_application3/presentation/support/support.dart';

class AppRoutes {

  static const String notificationsSettingsOneScreen =
      '/notifications_settings_one_screen';

  static const String permissionsSettingsScreen =
      '/permissions_settings_screen';

  static const String notificationsSettingsScreen =
      '/support';

  static Map<String, WidgetBuilder> routes = {
    notificationsSettingsOneScreen: (context) =>
        NotificationsSettingsOneScreen(),
    permissionsSettingsScreen: (context) => PermissionsSettingsScreen(),
    notificationsSettingsScreen: (context) => NotificationsSettingsScreen(),
  };
}
