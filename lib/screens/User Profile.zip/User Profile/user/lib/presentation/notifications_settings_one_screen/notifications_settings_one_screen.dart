import 'package:flutter/material.dart';
import 'package:nitish_s_application3/core/app_export.dart';
import 'package:nitish_s_application3/widgets/app_bar/appbar_leading_image.dart';
import 'package:nitish_s_application3/widgets/app_bar/appbar_title.dart';
import 'package:nitish_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:nitish_s_application3/widgets/custom_switch.dart';

class NotificationsSettingsOneScreen extends StatelessWidget {
  NotificationsSettingsOneScreen({Key? key})
      : super(
          key: key,
        );

  bool isSelectedSwitch = false;

  bool isSelectedSwitch1 = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 15.h,
            vertical: 16.v,
          ),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "notifications".toUpperCase(),
                      style: TextStyle(
                        color: theme.colorScheme.onPrimary,
                        fontSize: 14.fSize,
                        fontFamily: 'Montserrat',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 4.v),
                    SizedBox(
                      width: 47.h,
                      child: Divider(),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 11.v),
              _buildNotificationsFrame(context),
              SizedBox(height: 15.v),
              _buildFrame(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 40.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 24.v,
          bottom: 9.v,
        ),
      ),
      title: AppbarTitle(
        text: "Settings",
        margin: EdgeInsets.only(left: 8.h),
      ),
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildNotificationsFrame(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            SizedBox(
              width: 243.h,
              child: Text(
                "Allow app to send you notifications about payments, appointments.",
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: theme.colorScheme.secondaryContainer,
                  fontSize: 16.fSize,
                  fontFamily: 'Montserrat',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            SizedBox(height: 1.v),
            SizedBox(
              width: 246.h,
              child: Text(
                "Ensure that your app notifications are enabled to receive timely updates.",
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: appTheme.gray500,
                  fontSize: 13.fSize,
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ],
        ),
        CustomSwitch(
          margin: EdgeInsets.only(
            top: 18.v,
            bottom: 62.v,
          ),
          value: isSelectedSwitch,
          onChange: (value) {
            isSelectedSwitch = value;
          },
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildFrame(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: SizedBox(
                width: 270.h,
                child: Text(
                  "Allow notifications about the app updates.",
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: theme.colorScheme.secondaryContainer,
                    fontSize: 16.fSize,
                    fontFamily: 'Montserrat',
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
            CustomSwitch(
              margin: EdgeInsets.only(
                left: 36.h,
                top: 7.v,
                bottom: 10.v,
              ),
              value: isSelectedSwitch1,
              onChange: (value) {
                isSelectedSwitch1 = value;
              },
            ),
          ],
        ),
        SizedBox(height: 1.v),
        Container(
          width: 251.h,
          margin: EdgeInsets.only(right: 106.h),
          child: Text(
            "Get instant updates on latest features, improvements, and announcements.",
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: appTheme.gray500,
              fontSize: 13.fSize,
              fontFamily: 'Poppins',
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
      ],
    );
  }
}
