import 'package:flutter/material.dart';
import 'package:nitish_s_application3/core/app_export.dart';
import 'package:nitish_s_application3/widgets/app_bar/appbar_leading_image.dart';
import 'package:nitish_s_application3/widgets/app_bar/appbar_title.dart';
import 'package:nitish_s_application3/widgets/app_bar/appbar_trailing_iconbutton.dart';
import 'package:nitish_s_application3/widgets/app_bar/custom_app_bar.dart';
import 'package:nitish_s_application3/widgets/custom_switch.dart';

class PermissionsSettingsScreen extends StatelessWidget {
  PermissionsSettingsScreen({Key? key})
      : super(
          key: key,
        );

  bool isSelectedSwitch = false;

  bool isSelectedSwitch1 = false;

  bool isSelectedSwitch2 = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: _buildAppBar(context),
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(
            horizontal: 15.h,
            vertical: 16.v,
          ),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "App permissions".toUpperCase(),
                      style: TextStyle(
                        color: theme.colorScheme.onPrimary,
                        fontSize: 14.fSize,
                        fontFamily: 'Montserrat',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 4.v),
                    SizedBox(
                      width: 47.h,
                      child: Divider(),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10.v),
              _buildHeadingStyle(context),
              SizedBox(height: 14.v),
              _buildFrame1(context),
              SizedBox(height: 14.v),
              _buildFrame2(context),
              SizedBox(height: 5.v),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 40.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowDown,
        margin: EdgeInsets.only(
          left: 16.h,
          top: 24.v,
          bottom: 9.v,
        ),
      ),
      title: AppbarTitle(
        text: "Settings",
        margin: EdgeInsets.only(left: 8.h),
      ),
      actions: [
        AppbarTrailingIconbutton(
          imagePath: ImageConstant.imgIconoirCancel,
          margin: EdgeInsets.fromLTRB(16.h, 22.v, 16.h, 7.v),
        ),
      ],
      styleType: Style.bgFill,
    );
  }

  /// Section Widget
  Widget _buildHeadingStyle(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(top: 5.v),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Contacts and Message Syncing",
                  style: TextStyle(
                    color: theme.colorScheme.secondaryContainer,
                    fontSize: 16.fSize,
                    fontFamily: 'Montserrat',
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 2.v),
                SizedBox(
                  width: 243.h,
                  child: Text(
                    "Allow access to your contacts and messaging app for a convenient and integrated experience.",
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: appTheme.gray500,
                      fontSize: 13.fSize,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        CustomSwitch(
          margin: EdgeInsets.only(
            left: 54.h,
            bottom: 57.v,
          ),
          value: isSelectedSwitch,
          onChange: (value) {
            isSelectedSwitch = value;
          },
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildFrame1(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(top: 3.v),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Allow Camera Access",
                  style: TextStyle(
                    color: theme.colorScheme.secondaryContainer,
                    fontSize: 16.fSize,
                    fontFamily: 'Montserrat',
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 3.v),
                SizedBox(
                  width: 263.h,
                  child: Text(
                    "This is enable the app to use your device's camera for capturing photos of documents to upload medical records or documents securely within the app.",
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: appTheme.gray500,
                      fontSize: 13.fSize,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        CustomSwitch(
          margin: EdgeInsets.only(
            left: 43.h,
            bottom: 75.v,
          ),
          value: isSelectedSwitch1,
          onChange: (value) {
            isSelectedSwitch1 = value;
          },
        ),
      ],
    );
  }

  /// Section Widget
  Widget _buildFrame2(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.only(top: 5.v),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Third-Party Permissions",
                style: TextStyle(
                  color: theme.colorScheme.secondaryContainer,
                  fontSize: 16.fSize,
                  fontFamily: 'Montserrat',
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(height: 2.v),
              SizedBox(
                width: 246.h,
                child: Text(
                  "Some features may require access to third-party services for enhanced functionality.",
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: appTheme.gray500,
                    fontSize: 13.fSize,
                    fontFamily: 'Poppins',
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ],
          ),
        ),
        CustomSwitch(
          margin: EdgeInsets.only(bottom: 57.v),
          value: isSelectedSwitch2,
          onChange: (value) {
            isSelectedSwitch2 = value;
          },
        ),
      ],
    );
  }
}
